class Node:
    _atom_keys: list[int] = [21845, 13107, 3855, 255]
    _key_mask: int = 65535

    all_formula_tokens: list[str] = ['p0', 'p1', 'p2', 'p3', '(', ')', '!', '|', '&', '=>', '<=>']

    def __init__(self, key=None, depth=None, length=None, info=None) -> None:
        self._key: int = key
        self._depth: int = depth
        self._length: int = length
        self._info: float = info

        self._formula: str = None

    def __str__(self) -> str: return self.formula

    def __eq__(self, other):
        return isinstance(other, Node) and self.key == other.key
    
    def similar(self, other): pass

    def is_pure(self):
        for a in self._get_atoms():
            pos, neg = [], []
            for index, i in enumerate(format(self.key,'#018b')[2:]):
                (pos, neg)['0' == format(self._atom_keys[a],'#018b')[index + 2]].append(i)
            if pos == neg: return False
        return True

    @property
    def key(self) -> int:
        if self._key is None: self._key = self._get_key()
        return self._key

    @property
    def depth(self) -> int:
        if self._depth is None: self._depth = self._get_depth()
        return self._depth

    @property
    def length(self) -> int:
        if self._length is None: self._length = self._get_length()
        return self._length
    
    @property
    def info(self) -> int:
        if self._info is None: self._info = self._get_info()
        return self._info

    @property
    def formula(self) -> str:
        if self._formula is None: self._formula = self._get_formula()
        return self._formula
    
    def _get_atoms(self): return self._left._get_atoms() | self._right._get_atoms()

    def _get_formula(self, depth=0) -> str:
        if depth < 1:
            return f'{self._left._get_formula(depth=depth + 1)} {self._connective} {self._right._get_formula(depth=depth + 1)}'
        return f'({self._left._get_formula(depth=depth + 1)} {self._connective} {self._right._get_formula(depth=depth + 1)})'

    def _get_key(self) -> int: pass

    def _get_depth(self) -> int: return max(self._left.depth, self._right.depth) + 1

    def _get_length(self) -> int: return self._left.length + self._right.length

    def _get_info(self) -> float:
        return 1 - (sum([1 for i in range(16) if (self.key >> i) & 1 == 1]) / 16)
    
    @staticmethod
    def generate(depth):
        for i in range(4):
            yield Variable(id=i)
            yield Negation(Variable(id=i))

        if depth > 0:
            for left in Node.generate(depth - 1):
                for right in Node.generate(depth - 1):
                    if left != right:
                        yield Implication(left, right)
                        yield Disjunction(left, right)
                        yield Conjunction(left, right)
                        yield Biimplication(left, right)

    @staticmethod
    def split_key(key, keys):
        for i in keys:
            if i < key: continue
            
            for j in keys:
                if j < key: continue
            
                if i != key and j != key and i > j and i & j == key:
                    yield i, j

    @staticmethod
    def info_gain(target, *current) -> float:
        return sum([target.info - c.info for c in current]) / len(current)
    
    @staticmethod
    def info_key(key) -> float:
        return 1 - (sum([1 for i in range(16) if (key >> i) & 1 == 1]) / 16)

    @staticmethod
    def info_gain_key(target, *current) -> float:
        return max([Node.info_key(target)- Node.info_key(c) for c in current]) / len(current)
    
    @staticmethod
    def split_all_keys(keys):
        output = dict()
        for i in range(len(keys)):
            for j in range(i):
                value = keys[i] & keys[j]
                if value in keys and value != keys[i] and value != keys[j]:
                    if value not in output:
                        output[value] = {'split': [], 'info': []}
                    output[value]['split'] += [[keys[i], keys[j]]]
                    output[value]['info'] += [Node.info_gain_key(value, keys[i], keys[j]) ** 2]
        return output

    @staticmethod
    def parse(tokens):
        stack = []
        tokens.reverse()
        while tokens:
            stack.append(tokens.pop())
            reduced, stack = Node._reduce(stack)
            while reduced:
                reduced, stack = Node._reduce(stack)
        return stack[0] if len(stack) == 1 else None
    
    @staticmethod
    def create_dataset(depth = 2):
        database = dict()
        for f in Node.generate(depth):
            if f.is_pure():
                if f.key in database:
                    if f.length < database[f.key]['length']:
                        database[f.key]['length'] = f.length
                        database[f.key]['formulas'] = [{'leader':f, 'notations': [f]}]
                    elif f.length == database[f.key]['length']:
                        grouped = False
                        for group in database[f.key]['formulas']:
                            if group['leader'].similar(f):
                                grouped = True
                                group['notations'] += [f]
                                break
                        if not grouped:
                            database[f.key]['formulas'] += [{'leader':f, 'notations': [f]}]
                else:
                    database[f.key] = dict()
                    database[f.key]['length'] = f.length
                    database[f.key]['formulas'] = [{'leader':f, 'notations': [f]}]

        keys = Node.split_all_keys(list(database.keys()))
        for key in database:
            database[key]['info'] = Node.info_key(key) ** 2
            if key not in keys:
                database[key]['splits'] = None
            else:
                database[key]['splits'] = keys[key]['split']
                database[key]['info_gain'] = keys[key]['info']
        return database

    @staticmethod
    def _reduce(stack):
        for i in range(len(stack)):
            matched = Node._match(stack[- ( 1 + i) :])
            if matched:
                return True, stack[: - ( 1 + i)] + matched
        return False, stack
    
    @staticmethod
    def _match(stack):
        match stack:
            case ['p0']:
                return [Variable(0)]
            case ['p1']:
                return [Variable(1)]
            case ['p2']:
                return [Variable(2)]
            case ['p3']:
                return [Variable(3)]
            case ['!', x] if isinstance(x, Node):
                return [Negation(x)]
            case ['(', x, ')'] if isinstance(x, Node):
                return [x]
            case [l, '<=>', r] if isinstance(l, Node) and isinstance(r, Node):
                return [Biimplication(l, r)]
            case [l, '=>', r] if isinstance(l, Node) and isinstance(r, Node):
                return [Implication(l, r)]
            case [l, '&', r] if isinstance(l, Node) and isinstance(r, Node):
                return [Conjunction(l, r)]
            case [l, '|', r] if isinstance(l, Node) and isinstance(r, Node):
                return [Disjunction(l, r)]

        return None


class Variable(Node):
    def __init__(self, id: int) -> None:
        super().__init__(key= Node._atom_keys[id], depth=0, length=1, info=0.5)
        self._id = id
    
    def similar(self, other): return self.key != other.key or not isinstance(other, Variable)

    def _get_atoms(self): return {self._id}

    def _get_formula(self, depth=0) -> str:
        return f'p{self._id}'
    
    def _get_length(self) -> int: return 1


class Negation(Node):
    def __init__(self, expression) -> None:
        super().__init__()
        self._expression: Variable = expression

    def similar(self, other): return self.key != other.key or not isinstance(other, Negation)

    def _get_atoms(self): return {self._expression._id}

    def _get_formula(self, depth=0) -> str:
        return f'!{self._expression._get_formula()}'
    
    def _get_key(self) -> int: return Node._key_mask - self._expression.key

    def _get_depth(self) -> int: return self._expression.depth

    def _get_length(self) -> int: return self._expression._get_length()


class Disjunction(Node):
    def __init__(self, left, right) -> None:
        super().__init__()
        self._left: Node = left
        self._right: Node = right
        self._connective: str = '|'

    def _get_key(self) -> int: return self._left.key | self._right.key

    def similar(self, other):
        if self.key != other.key or not isinstance(other, Disjunction): return False
        return ((self._left.similar(other._left) and self._right.similar(other._right)) or 
                (self._left.similar(other._right) and self._right.similar(other._left)))


class Conjunction(Node):
    def __init__(self, left, right) -> None:
        super().__init__()
        self._left: Node = left
        self._right: Node = right
        self._connective: str = '&'
    
    def _get_key(self) -> int: return self._left.key & self._right.key

    def similar(self, other):
        if self.key != other.key or not isinstance(other, Conjunction): return False
        return ((self._left.similar(other._left) and self._right.similar(other._right)) or 
                (self._left.similar(other._right) and self._right.similar(other._left)))


class Implication(Node):
    def __init__(self, left, right) -> None:
        super().__init__()
        self._left: Node = left
        self._right: Node = right
        self._connective: str = '=>'

    def _get_key(self) -> int: return self._left.key | (Node._key_mask - self._right.key)

    def similar(self, other):
        if self.key != other.key or not isinstance(other, Implication): return False
        return self._left.similar(other._left) and self._right.similar(other._right)


class Biimplication(Node):
    def __init__(self, left, right) -> None:
        super().__init__()
        self._left: Node = left
        self._right: Node = right
        self._connective: str = '<=>'

    def _get_key(self) -> int: return Node._key_mask - (self._left.key ^ self._right.key)

    def similar(self, other):
        if self.key != other.key or not isinstance(other, Biimplication): return False
        return ((self._left.similar(other._left) and self._right.similar(other._right)) or 
                (self._left.similar(other._right) and self._right.similar(other._left)))
    

if __name__ == '__main__':
    database = Node.create_dataset(2)
    for x in list(database.keys())[:25]:
        print(f'key: {x}')
        print(f'    length: {database[x]['length']}')
        for fr in database[x]['formulas']:
            print(f'        leader: {fr['leader']}')
            for n in fr['notations']:
                print(f'            {str(n)}')
    # total = 0
    # database = dict()
    # for f in Node.generate(2):
    #     total += 1
    #     if f.is_pure():
    #         if f.key in database:
    #             if f.length < database[f.key]['len']:
    #                 database[f.key]['len'] = f.length
    #                 database[f.key]['form'] = [f]
    #             elif f.length == database[f.key]['len']:
    #                 database[f.key]['form'] += [f]
    #         else:
    #             database[f.key] = dict()
    #             database[f.key]['len'] = f.length
    #             database[f.key]['form'] = [f]

    # good = []
    # for k in database:
    #     good += [(f, k) for f in database[k]['form']]
    
    # print(total, len(good))
    # for i, j in good[:100]:
    #     print(str(i),j)
    #print(Node.parse(['p0', '<=>', '(', 'p0', '|', '!', 'p0', ')']).key)